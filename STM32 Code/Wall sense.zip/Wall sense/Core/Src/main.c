/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"


#include "lcd_stm32f0.h"
#include "stdio.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

//Lungelo Medthod add
void pwm_alt(void);
void adc_comp(void);
uint16_t adc_value_1;
uint16_t adc_value_2;
uint16_t adc_value_3;

uint16_t adc_ref1;
uint16_t adc_ref2;
uint16_t adc_ref3;

uint8_t channel = 0;
void adc_set_channel(uint8_t num);


char LCD_buffer[32]; 
//end

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  init_LCD();

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    pwm_alt();

    adc_comp();

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI14|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void pwm_alt(void){//alternate turning on IR LEDs
    HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
    HAL_Delay(1000);
    HAL_TIM_PWM_Stop(&htim2,TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
    HAL_Delay(1000);
    HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
    HAL_Delay(1000);
    HAL_TIM_PWM_Stop(&htim3,TIM_CHANNEL_2);
}

void adc_comp(void){
   adc_ref1 = 1784;
   adc_ref2 = 1500;
   adc_ref3 = 830;
  
   ADC1 -> CHSELR = ADC_CHSELR_CHSEL1;

   
   HAL_ADC_Start(&hadc);
   HAL_Delay(10);
   while(HAL_ADC_PollForConversion(&hadc,HAL_MAX_DELAY)!= HAL_OK);
   adc_value_1 = HAL_ADC_GetValue(&hadc);
   HAL_ADC_Stop(&hadc);

   ADC1 -> CHSELR = ADC_CHSELR_CHSEL2;

   HAL_ADC_Start(&hadc);
   HAL_Delay(10);
   while(HAL_ADC_PollForConversion(&hadc,HAL_MAX_DELAY)!= HAL_OK);
   adc_value_2 = HAL_ADC_GetValue(&hadc);
   HAL_ADC_Stop(&hadc);

   ADC1 -> CHSELR = ADC_CHSELR_CHSEL3;

   HAL_ADC_Start(&hadc);
   HAL_Delay(10);
   while(HAL_ADC_PollForConversion(&hadc,HAL_MAX_DELAY)!= HAL_OK);
   adc_value_3 = HAL_ADC_GetValue(&hadc);
   HAL_ADC_Stop(&hadc);
    
    lcd_command(CLEAR);
    sprintf(LCD_buffer, " 1: %d", adc_value_3); // Convert integer to string
    lcd_putstring(LCD_buffer);
    lcd_command(LINE_TWO);
    sprintf(LCD_buffer, " 2: %d", adc_value_2); // Convert integer to string
    lcd_putstring(LCD_buffer);
    sprintf(LCD_buffer, " 3: %d", adc_value_1); // Convert integer to string
    lcd_putstring(LCD_buffer);
    HAL_Delay(175);

   if ((adc_value_1 > adc_ref1)){
       HAL_GPIO_WritePin(right3_GPIO_Port, right3_Pin, SET);
   }
   else{
       HAL_GPIO_WritePin(right3_GPIO_Port, right3_Pin, RESET);
   }

   //HAL_Delay(50);

   if ((adc_value_2 >= adc_ref2)){
       HAL_GPIO_WritePin(front2_GPIO_Port, front2_Pin, SET);
   }
   else{
       HAL_GPIO_WritePin(front2_GPIO_Port, front2_Pin, RESET);

   }

   //HAL_Delay(50);

   if ((adc_value_3 > adc_ref3)){
       HAL_GPIO_WritePin(left1_GPIO_Port, left1_Pin, SET);
   }
   else{
       HAL_GPIO_WritePin(left1_GPIO_Port, left1_Pin, RESET);
   }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
